﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prototype
{
    class Stage1 : GameState
    {
        public Background background { get; set; }
        public Player player { get; set; }

        public Stage1()
        {
            background = new Background("Underworld 1.png");
            player = new Player();
        }

        public override void Draw(Graphics g)
        {
            background.Draw(g);
            player.Draw(g);
        }

        public override void KeyPressed(object sender, KeyEventArgs e)
        {
            if(e.KeyData == Keys.D)
            {
                if(background.right != 2045)
                {
                    background.x += 10;
                    background.right+= 10;
                    int temp = player.index++;
                    Console.WriteLine(temp);
                    player.setIndex(temp);
                }
                else
                {
                    background.x += 10;
                    background.left += 10;
                    int temp = player.index++;
                    player.setIndex(temp);
                }

            }
            else if (e.KeyData == Keys.A)
            {
                if (background.left != -2045)
                {
                    background.x -= 10;
                    background.left -= 10;
                    player.setIndex(player.index--);
                }
                else
                {
                    background.x -= 10;
                    background.right -= 10;
                    player.setIndex(player.index--);
                }

            }
        }
    }
}
