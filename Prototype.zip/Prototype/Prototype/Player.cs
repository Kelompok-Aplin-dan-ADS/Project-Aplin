﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype
{
    class Player
    {
        public List<Bitmap> Avatar { get; set; } = new List<Bitmap>();
        public List<Bitmap> Idle { get; set; } = new List<Bitmap>();
        public Status status { get; set; }

        public int index { get; set; }

        public Player()
        {
            index = 0;
            status = Status.idle;
            //addIdle();

            Avatar.Add(new Bitmap("assets\\char\\Run (1).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (2).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (3).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (4).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (5).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (6).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (7).png"));
            Avatar.Add(new Bitmap("assets\\char\\Run (8).png"));

            //set keadaan
            //setAvatar(status);
        }

        public int setIndex(int index)
        {
            if(this.index == 8)
            {
                return this.index = 0;
            }
            else if(this.index == -1)
            {
                return this.index = 8;
            }
            else
            {
                return this.index;
            }
        }

        public void addIdle()
        {
            //Idle.Add(new Bitmap("Prototype\\assets\\char\\Idle\\Idle (1).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (2).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (3).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (4).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (5).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (6).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (7).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (8).png"));
            //Idle.Add(new Bitmap("\\Prototype\\assets\\char\\Idle\\Idle (9).png"));
        }

        public void setAvatar(Status status)
        {
            if(status == Status.idle)
            {
                for (int i = 0; i < Idle.Count; i++)
                {
                    Avatar[i] = Idle[i];
                }
            }
        }

        public void Draw(Graphics g)
        {
            g.DrawImage(Avatar[index],0,200,300,300);
            //index++;
        }
    }
    public enum Status
    {
        idle,
        run,
        jump
    }
}
